const Collection = artifacts.require("Collection");

module.exports = function (deployer) {
  deployer.deploy(Collection);
};
